import sqlite3
import datetime
from flask import Flask, render_template, g, request, redirect, url_for


PATH = 'db/jobs.sqlite'

app = Flask(__name__)


def open_connection():
    connection = getattr(g, '_connection', None)
    if connection == None:
        connection = g._connection = sqlite3.connect(PATH)
    connection.row_factory = sqlite3.Row
    return connection


def execute_sql(sql, values=(), commit=False, single=False):
    connection = open_connection()
    cursor = connection.execute(sql, values)
    if commit == True:
        results = connection.commit()
    else:
        results = cursor.fetchone() if single else cursor.fetchall()

    cursor.close()
    return results

@app.teardown_appcontext
def close_connection(exception):
    connection = getattr(g, '_connection', None)
    if connection is not None:
        connection.close()


@app.route('/')
def home():
    return render_template('index.html')


@app.route('/book/')
def book():
    return render_template('books.html')


@app.route('/authors/')
def authors():
    return render_template('authors.html')


@app.route('/review/')
def review():
    return render_template('review.html')


@app.route('/horror/')
def horror():
    return render_template('horror.html')


@app.route('/fantasy/')
def fantasy():
    return render_template('fantasy.html')


@app.route('/science_fiction/')
def science_fiction():
    return render_template('science_fiction.html')


@app.route('/horror_one/')
def horror_one():
    return render_template('horror_one.html')


@app.route('/horror_two/')
def horror_two():
    return render_template('horror_two.html')


@app.route('/horror_three/')
def horror_three():
    return render_template('horror_three.html')


@app.route('/fantasy_one/')
def fantasy_one():
    return render_template('fantasy_one.html')


@app.route('/fantasy_two/')
def fantasy_two():
    return render_template('fantasy_two.html')


@app.route('/fantasy_three/')
def fantasy_three():
    return render_template('fantasy_three.html')


@app.route('/science_one/')
def scifi_one():
    return render_template('scifi_one.html')


@app.route('/science_two/')
def scifi_two():
    return render_template('scifi_two.html')


@app.route('/science_three/')
def scifi_three():
    return render_template('scifi_three.html')


if __name__ == '__main__':
    app.run(debug=True)
